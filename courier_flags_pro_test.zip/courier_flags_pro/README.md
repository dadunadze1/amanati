# Courier FLAGS PRO — Test Build

სატესტო frontend ვერსია GitHub Pages-ისთვის.

## ფაილები
- index.html
- style.css
- app.js
- firebase.js
- auth.js
- map.js
- admin.js
- courier.js
- modules/

## გამოყენება
1. შექმენი Firebase project.
2. ჩართე Authentication -> Email/Password.
3. შექმენი Firestore Database.
4. სურვილისამებრ ჩართე Storage.
5. `firebase.js`-ში ჩასვი შენი Firebase config.
6. ატვირთე ყველა ფაილი GitHub repository-ში.
7. GitHub Pages-ში source მიუთითე main/root.

## Firestore collections
- users
- couriers
- clients
- orders
- interactions
- staffPerformance
- gpsLocations
- autoReplies
- schedules
- payroll
- documents
- analytics
- reports
- knowledgeBase
- accounting
- equipment

## შენიშვნა
ეს არის სატესტო frontend + Firebase Auth/Firestore ჩონჩხი. სერვერულ ვერსიაში დაემატება უსაფრთხოების წესები, Cloud Functions, PDF generation, real analytics და production არქიტექტურა.
